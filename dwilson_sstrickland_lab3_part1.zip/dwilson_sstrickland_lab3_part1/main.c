/*David Wilson (862134618) dwils036@ucr.edu
 * Partner: Steven Strickland sstri014@ucr.edu
 * Lab Section: 023
 * Assignment: Lab 3 Exercise 1
 * Bit Manipulation
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */ 

#include <avr/io.h>



unsigned char GetBits(unsigned char a,unsigned char b)
{
	return ((a & (0x01<<b))!=0);
}



int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0x00; PORTB = 0xFF; // Configure port B's 8 pins as inputs
	DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs
	unsigned char cnt =0x00;
	unsigned char i=0x00;
    
    while (1) 
	{
		for (i=0; i<8; i++)
		{
		
			if (GetBits(PINA,i))
			cnt++;
			if (GetBits(PINB,i))
			cnt++;
		}
		PORTC=cnt;
		
    }
	return 0;
}


