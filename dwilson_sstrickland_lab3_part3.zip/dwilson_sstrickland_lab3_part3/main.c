/*David Wilson dwils036@ucr.edu
 * Partner: Hector Soto Jr
 *Lab Section: 023
 * Assignment: Lab 3 Exercise 2
 *
 *
 *I acknowledge all content contained herein, excluding template or example code, 
 *is my own original work
 */ 
#include <avr/io.h>

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRC = 0xFF; PORTC = 0x00; // Configure port B's 8 pins as outputs
	DDRD = 0xFF; PORTD = 0x00; // Configure port B's 8 pins as outputs

	unsigned char fuel_1=0x00; // fuel level 1&2 PC 5     (0x20) (fuel light on)
	unsigned char fuel_2=0x00; // fuel level 3&4 PC 4&5   (0x30) (fuel light on)
	unsigned char fuel_3=0x00; // fuel level 5&6 PC 3-5   (0x38) 
	unsigned char fuel_4=0x00; // fuel level 7-9 PC 2-5   (0x3C)
	unsigned char fuel_5=0x00; // fuel level 10-12 PC 1-5 (0x3E)
	unsigned char fuel_6=0x00; // fuel level 12-15 PC 0-5 (0x3F)
	unsigned char totalAvalGas = 0x00;
	unsigned char seatBlt = 0x00; // seatBltWarning (dont eat blt)
	


	while (1)
	{
		totalAvalGas=PINA&0x0F;
		
		seatBlt=PINA&0xF0;
		

	
		if(totalAvalGas<3&&totalAvalGas>-1)//0-2
		{
			fuel_1=0x20;
			PORTC=fuel_1|0x40; //|0x80 bit masking to show low fuel
			
		}
		
		
		if(totalAvalGas<5&&totalAvalGas>2)//3-4
		{
			fuel_2=0x30;
			PORTC=fuel_2|0x40; //|0x80 bit masking to show low fuel
		
		}
		
		
		if(totalAvalGas<7&&totalAvalGas>4)//5-6
		{
			fuel_3=0x38;
			PORTC=fuel_3;
			
		}
		
		
		if(totalAvalGas<10&&totalAvalGas>6)//7-9
		{
			fuel_4=0x3C;
			PORTC=fuel_4;
			
		}
		
		if (totalAvalGas<13&&totalAvalGas>9)//10-12
		{
			fuel_5=0x3E;
			PORTC = fuel_5;
			
		}
		
		if (totalAvalGas<16&&totalAvalGas>11)//12-15
		{
			fuel_6=0x3F;
			PORTC=fuel_6;
			
		}
		
		if (seatBlt==0x30){
			PORTC=PORTC|0x80;
			
		}
		
		
		
		
		
	}	
	
}

